'use client'
import * as XLSX from 'xlsx'
import { useState, useEffect, useCallback, useRef } from 'react'
import Header from '@/components/layout/Header'
import api from '@/lib/api'
import { useMutation, useDebounce, useApiData } from '@/lib/hooks'
import { useToast } from '@/components/ui/feedback'
import { formatNumber } from '@/lib/utils'
import DynamicSelect from '@/components/ui/DynamicSelect'
import {
  Search, Plus, Edit, Trash2, HelpCircle, RefreshCw,
  ChevronLeft, ChevronRight,
  X, Check, Layers, Clock, Coins, Target, BookOpen,
  ListPlus, Eye, AlertCircle, CheckCircle2, Filter,
  ChevronDown, Pencil, Loader2, Upload, FileSpreadsheet, Download, AlertTriangle,
} from 'lucide-react'

const LIMIT = 15

const TYPE_META: Record<string,{label:string;color:string;bg:string}> = {
  daily: { label:'Daily',      color:'text-purple-700', bg:'bg-purple-100 border-purple-200' },
  topic: { label:'Topic',      color:'text-blue-700',   bg:'bg-blue-100 border-blue-200' },
  mock:  { label:'Mock Test',  color:'text-orange-700', bg:'bg-orange-100 border-orange-200' },
}

const OPTION_LABELS = ['A','B','C','D','E']
const LETTER_TO_IDX: Record<string,number> = { a:0, b:1, c:2, d:3, e:4 }
const normCorrect = (v: any): number => {
  if (typeof v === 'number') return Math.min(v, 3)
  if (typeof v === 'string') return LETTER_TO_IDX[v.toLowerCase()] ?? 0
  return 0
}

// Issue 8: controlled number input — shows empty string not 0
function NumInput({ value, onChange, placeholder='', className='', min=0, max=9999 }:
  {value:number; onChange:(v:number)=>void; placeholder?:string; className?:string; min?:number; max?:number}) {
  const [raw, setRaw] = useState(value === 0 ? '' : String(value))
  useEffect(() => { setRaw(value === 0 ? '' : String(value)) }, [value])
  return (
    <input
      type="number" className={`input ${className}`}
      value={raw} min={min} max={max}
      placeholder={placeholder || String(min)}
      onChange={e => { setRaw(e.target.value); const n = parseInt(e.target.value); if (!isNaN(n)) onChange(n) }}
      onBlur={() => { if (raw === '' || isNaN(Number(raw))) { setRaw(''); onChange(0) } }}
    />
  )
}

// Decimal-capable variant of NumInput — used for marks-per-question fields
// (e.g. +2, -0.66) where NumInput's parseInt would truncate fractions.
function DecimalInput({ value, onChange, placeholder='', className='', min=0, max=99, step=0.25 }:
  {value:number; onChange:(v:number)=>void; placeholder?:string; className?:string; min?:number; max?:number; step?:number}) {
  const [raw, setRaw] = useState(value === 0 ? '' : String(value))
  useEffect(() => { setRaw(value === 0 ? '' : String(value)) }, [value])
  return (
    <input
      type="number" step={step} className={`input ${className}`}
      value={raw} min={min} max={max}
      placeholder={placeholder || String(min)}
      onChange={e => { setRaw(e.target.value); const n = parseFloat(e.target.value); if (!isNaN(n)) onChange(n) }}
      onBlur={() => { if (raw === '' || isNaN(Number(raw))) { setRaw(''); onChange(0) } }}
    />
  )
}

const EMPTY_FORM = {
  title:'', subject:'', type:'topic',
  totalQuestions:10, durationMins:15,
  coinsReward:10, status:'draft', scheduledFor:'',
  examTags:[] as string[],
  negativeMarkingEnabled:false, marksPerCorrect:1, marksPerWrong:0,
  shuffleQuestions:true, shuffleOptions:true,
  isExamMode: false,
}

// Issue 13: admin chooses option count (2–5)
function emptyQ(optCount=4) {
  optCount = Math.min(optCount, 4) // DB max is 4
  return {
    question:'', questionType:'text', questionImageUrl:'',
    optionType:'text', options:Array(optCount).fill(''), optionImages:Array(optCount).fill(''),
    correctOption:0,
    explanation:'',
    optionCount:optCount,
    // Match the Following fields
    questionSubtype: 'standard' as 'standard'|'match',
    matchList1: [{ label:'A', text:'' }, { label:'B', text:'' }, { label:'C', text:'' }, { label:'D', text:'' }],
    matchList2: [{ label:'1', text:'' }, { label:'2', text:'' }, { label:'3', text:'' }, { label:'4', text:'' }],
  }
}


// ─── Bulk Quiz Upload ─────────────────────────────────────────

function downloadTemplate() {
  const wb = XLSX.utils.book_new()
  const infoRows = [
    ['Field', 'Your Value  <- Fill here', 'Allowed values / notes'],
    ['title',         'My Quiz Title',  'Required. Quiz name shown in the app.'],
    ['subject',       'Polity',         'Required. e.g. Polity, History, Bihar GK, Economy'],
    ['type',          'topic',          'topic  /  mock  /  daily   (default: topic)'],
    ['duration_mins', '15',             'Duration in minutes  (default: 15)'],
    ['coins_reward',  '10',             'Coins given on completion  (default: 10)'],
    ['status',        'published',      'published  (live in app)  or  draft  (hidden)'],
  ]
  const wsInfo = XLSX.utils.aoa_to_sheet(infoRows)
  wsInfo['!cols'] = [{ wch: 22 }, { wch: 40 }, { wch: 38 }]
  XLSX.utils.book_append_sheet(wb, wsInfo, 'Quiz Info')

  const qRows = [
    // Columns: quiz_title, question, option_a–e, correct_option, explanation, subject  ← standard columns (same as before)
    // NEW: question_subtype (standard/match), list1_a–d, list2_1–4  ← leave blank for standard MCQs; fill for match questions
    ['quiz_title', 'question', 'option_a', 'option_b', 'option_c', 'option_d', 'option_e', 'correct_option', 'explanation', 'subject', 'question_subtype', 'list1_a', 'list1_b', 'list1_c', 'list1_d', 'list2_1', 'list2_2', 'list2_3', 'list2_4'],
    // ── Standard MCQ examples (leave match columns blank) ──
    ['Bihar GK Quiz 1', 'What is the capital of Bihar?', 'Patna', 'Ranchi', 'Gaya', 'Muzaffarpur', '', 'a', 'Patna has been the capital since ancient times.', 'Bihar GK', 'standard', '', '', '', '', '', '', '', ''],
    ['Bihar GK Quiz 1', 'Who was the first Chief Minister of Bihar?', 'Shri Krishna Sinha', 'Anugrah Narayan Sinha', 'Binodanand Jha', 'Mahamaya Prasad Sinha', '', 'a', 'Sri Krishna Sinha became the first CM in 1946.', 'Bihar GK', 'standard', '', '', '', '', '', '', '', ''],
    ['Geography Quiz 1', 'Which river flows through Patna?', 'Ganga', 'Yamuna', 'Godavari', 'Kaveri', '', 'a', 'The Ganga river flows through Patna.', 'Geography', 'standard', '', '', '', '', '', '', '', ''],
    ['Polity Quiz 1', 'Article 370 was related to which state?', 'Jammu & Kashmir', 'Himachal Pradesh', 'Uttarakhand', 'Sikkim', '', 'a', 'Article 370 granted special status to J&K.', 'Polity', 'standard', '', '', '', '', '', '', '', ''],
    ['History Quiz 1', 'Who is the Iron Man of India?', 'Sardar Vallabhbhai Patel', 'Subhas Chandra Bose', 'Bal Gangadhar Tilak', 'Lal Bahadur Shastri', '', 'a', 'Sardar Patel unified the princely states.', 'History', 'standard', '', '', '', '', '', '', '', ''],
    // ── Match the Following example ──
    // option_a–d = the 4 combination choices the student picks from
    // list1_a–d  = List-I items (left side)
    // list2_1–4  = List-II items (right side)
    ['History Quiz 1', 'Match the dynasties with their capitals', 'A-1, B-2, C-3, D-4', 'A-2, B-1, C-3, D-4', 'A-1, B-3, C-2, D-4', 'A-3, B-4, C-1, D-2', '', 'a', 'Maurya capital was Pataliputra, Gupta was Ujjain', 'History', 'match', 'Maurya', 'Gupta', 'Chola', 'Pallava', 'Pataliputra', 'Ujjain', 'Thanjavur', 'Kanchipuram'],
  ]
  const wsQ = XLSX.utils.aoa_to_sheet(qRows)
  wsQ['!cols'] = [
    { wch: 18 }, { wch: 36 }, { wch: 22 }, { wch: 22 }, { wch: 22 }, { wch: 22 }, { wch: 16 }, { wch: 14 }, { wch: 32 }, { wch: 18 },
    { wch: 14 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 },
  ]
  XLSX.utils.book_append_sheet(wb, wsQ, 'Quiz Questions')

  // ── Match the Following Guide sheet ──────────────────────────────────────
  const matchGuideRows = [
    ['MATCH THE FOLLOWING — HOW TO FILL'],
    [''],
    ['Set  question_subtype = match  in the "Quiz Questions" sheet to enable this question type.'],
    [''],
    ['STEP 1 — Fill the question text (what the student reads)'],
    ['  question  →  "Match List-I with List-II"'],
    [''],
    ['STEP 2 — Fill List-I items (left column the student sees)'],
    ['  list1_a  →  Item A   e.g. Maurya'],
    ['  list1_b  →  Item B   e.g. Gupta'],
    ['  list1_c  →  Item C   (optional)'],
    ['  list1_d  →  Item D   (optional)'],
    [''],
    ['STEP 3 — Fill List-II items (right column the student sees)'],
    ['  list2_1  →  Item 1   e.g. Pataliputra'],
    ['  list2_2  →  Item 2   e.g. Ujjain'],
    ['  list2_3  →  Item 3   (optional)'],
    ['  list2_4  →  Item 4   (optional)'],
    [''],
    ['STEP 4 — Fill the 4 COMBINATION choices (option_a to option_d)'],
    ['  These are the 4 answer options that appear as buttons in the app.'],
    ['  Each is a combination like: "A-1, B-2, C-3, D-4"'],
    [''],
    ['  option_a  →  A-1, B-2, C-3, D-4   ← this is the correct one if correct_option = a'],
    ['  option_b  →  A-2, B-1, C-3, D-4'],
    ['  option_c  →  A-1, B-3, C-2, D-4'],
    ['  option_d  →  A-3, B-4, C-1, D-2'],
    [''],
    ['STEP 5 — Set correct_option to a / b / c / d (which combination is correct)'],
    [''],
    ['VISUAL EXAMPLE (how it looks in the app):'],
    [''],
    ['  List-I          List-II'],
    ['  A. Maurya  →   1. Pataliputra'],
    ['  B. Gupta   →   2. Ujjain'],
    ['  C. Chola   →   3. Thanjavur'],
    ['  D. Pallava →   4. Kanchipuram'],
    [''],
    ['  (a) A-1, B-2, C-3, D-4  ✓ correct'],
    ['  (b) A-2, B-1, C-3, D-4'],
    ['  (c) A-1, B-3, C-2, D-4'],
    ['  (d) A-3, B-4, C-1, D-2'],
    [''],
    ['NOTE: list1 and list2 must have at least 2 items each. Minimum: list1_a, list1_b, list2_1, list2_2.'],
  ]
  const wsGuide = XLSX.utils.aoa_to_sheet(matchGuideRows)
  wsGuide['!cols'] = [{ wch: 80 }]
  XLSX.utils.book_append_sheet(wb, wsGuide, 'Match Guide')

  XLSX.writeFile(wb, 'quiz_bulk_upload_template.xlsx')
}

function parseCSV(text: string): any[][] {
  const rows: any[][] = []
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue
    const cols: string[] = []
    let cur = '', inQuote = false
    for (let i = 0; i < line.length; i++) {
      const ch = line[i]
      if (ch === '"') { inQuote = !inQuote }
      else if (ch === ',' && !inQuote) { cols.push(cur); cur = '' }
      else cur += ch
    }
    cols.push(cur)
    rows.push(cols.map(c => c.replace(/^"|"$/g, '').trim()))
  }
  return rows
}

function extractMetaFromSheet(wb: any): Record<string, string> {
  const infoSheet = wb.Sheets['Quiz Info'] || wb.Sheets['quiz_info'] || wb.Sheets['QuizInfo']
  if (!infoSheet) return {}
  const rows: any[] = XLSX.utils.sheet_to_json(infoSheet, { header: 1, defval: '' })
  const KNOWN = ['title', 'subject', 'type', 'duration_mins', 'duration', 'coins_reward', 'coins', 'status']
  const meta: Record<string, string> = {}
  for (const row of rows) {
    const r = row as any[]
    const key = String(r[0] || '').trim().toLowerCase().replace(/\s*\*/g, '').replace(/\s+/g, '_').trim()
    const val = String(r[1] || '').trim()
    if (KNOWN.includes(key) && val) meta[key] = val
  }
  return meta
}

async function parseFile(file: File): Promise<{ questions: any[]; quizMeta: Record<string, string> }> {
  const isCsv = file.name.toLowerCase().endsWith('.csv')
  let rows: any[][]
  let quizMeta: Record<string, string> = {}

  if (!isCsv) {
    const buf = await file.arrayBuffer()
    const wb = XLSX.read(buf, { type: 'array' })
    quizMeta = extractMetaFromSheet(wb)
    const qSheetName = wb.SheetNames.find((n: string) => n.toLowerCase().includes('question'))
      || wb.SheetNames[wb.SheetNames.length - 1]
    rows = XLSX.utils.sheet_to_json(wb.Sheets[qSheetName], { header: 1, defval: '' }) as any[][]
  } else {
    rows = parseCSV(await file.text())
  }

  if (rows.length < 2) throw new Error('File is empty or has no data rows')

  // Find header row — scan first 10 rows for one containing "question"
  let headerIdx = 0
  for (let i = 0; i < Math.min(rows.length, 10); i++) {
    const cells = (rows[i] as any[]).map((c: any) => String(c).trim().toLowerCase().replace(/\s*\*/g, '').trim())
    if (cells.some((c: string) => c === 'question' || c === 'question_text')) {
      headerIdx = i
      break
    }
  }

  // Clean headers: strip *, spaces, underscores
  const headers: string[] = (rows[headerIdx] as any[]).map((h: any) =>
    String(h).trim().toLowerCase().replace(/\s*\*/g, '').replace(/\s+/g, '_').trim().replace(/^_+|_+$/g, '')
  )

  const questions: any[] = []
  for (let i = headerIdx + 1; i < rows.length; i++) {
    const row = rows[i] as any[]
    if (row.every((c: any) => !String(c).trim())) continue
    const obj: any = {}
    headers.forEach((h: string, j: number) => { if (h) obj[h] = String(row[j] ?? '').trim() })
    questions.push(obj)
  }
  return { questions, quizMeta }
}

/**
 * Picks the subject for a detected quiz group by majority vote across its rows,
 * falling back to the form's global subject only when no row has one set.
 *
 * FIX: previously this just took `qs[0]?.subject` — whichever row happened to
 * be first in the sheet. For a quiz_title group whose rows span several
 * subjects (e.g. "Polity Quiz 1" containing 2 Bihar GK + 1 Geography + 2 Polity
 * questions — a realistic mix for this kind of exam content), the quiz-level
 * subject ended up being whatever subject the FIRST row happened to carry,
 * regardless of how representative that was, and regardless of what the admin
 * had typed into the "Subject" field in Quiz Details (that field is only used
 * when a row's subject is blank, so editing it has no effect once every row
 * already has a subject — which the column reference panel actively
 * encourages by labelling `subject` "optional per-question"). Majority vote
 * is a strictly better default; `mixedSubjectInfo` below surfaces the
 * remaining ambiguous cases (genuine ties) so the admin can fix them by
 * editing the per-row Subject cells before importing, instead of finding out
 * after the quiz is already created.
 */
function majoritySubject(qs: any[], fallback: string): string {
  const tally: Record<string, number> = {}
  for (const q of qs) {
    const s = (q.subject || '').trim()
    if (s) tally[s] = (tally[s] || 0) + 1
  }
  let best = ''
  let bestCount = 0
  for (const [s, c] of Object.entries(tally)) {
    if (c > bestCount) { best = s; bestCount = c }
  }
  return best || fallback
}

/** Distinct non-empty subjects present in a group, for the mixed-subject warning. */
function distinctSubjects(qs: any[]): string[] {
  return Array.from(new Set(qs.map(q => (q.subject || '').trim()).filter(Boolean)))
}

function BulkQuizUpload({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [step, setStep] = useState<'upload' | 'preview' | 'done'>('upload')
  const [questions, setQuestions] = useState<any[]>([])
  const [parseError, setParseError] = useState<string | null>(null)
  const [importing, setImporting] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [dragOver, setDragOver] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [meta, setMeta] = useState({ title: '', subject: '', type: 'topic', durationMins: 15, coinsReward: 10, status: 'published', negativeMarkingEnabled: false, marksPerCorrect: 1, marksPerWrong: 0 })

  const FIELD_MAP: Record<string, string> = {
    quiz_title: 'quiz_title', quiz: 'quiz_title',
    question: 'question', question_text: 'question', q: 'question',
    option_a: 'option_a', a: 'option_a',
    option_b: 'option_b', b: 'option_b',
    option_c: 'option_c', c: 'option_c',
    option_d: 'option_d', d: 'option_d',
    option_e: 'option_e', e: 'option_e',
    correct_option: 'correct_option', answer: 'correct_option', correct: 'correct_option',
    explanation: 'explanation', hint: 'explanation',
    subject: 'subject',
    // Match the Following support
    question_subtype: 'question_subtype', subtype: 'question_subtype', type: 'question_subtype',
    list1_a: 'list1_a', list1_b: 'list1_b', list1_c: 'list1_c', list1_d: 'list1_d',
    list2_1: 'list2_1', list2_2: 'list2_2', list2_3: 'list2_3', list2_4: 'list2_4',
  }

  const normalise = (rows: any[]) => rows.map(r => {
    const out: any = {}
    Object.entries(r).forEach(([k, v]) => {
      const mapped = FIELD_MAP[k.toLowerCase().replace(/\s+/g, '_')]
      if (mapped) out[mapped] = v
    })
    return out
  })

  const handleFile = async (file: File) => {
    setParseError(null)
    try {
      const { questions: raw, quizMeta } = await parseFile(file)
      const norm = normalise(raw)
      if (norm.length === 0) throw new Error('No valid rows found')
      if (norm.length > 500) throw new Error('Maximum 500 questions per upload')
      setQuestions(norm)
      const TYPE_MAP: Record<string, string> = { topic: 'topic', mock: 'mock', daily: 'daily', 'mock test': 'mock' }
      setMeta(m => ({
        ...m,
        title:        quizMeta['title']        || m.title,
        subject:      quizMeta['subject']       || norm[0]?.subject || m.subject,
        type:         TYPE_MAP[String(quizMeta['type'] || '').toLowerCase()] || m.type,
        durationMins: parseInt(quizMeta['duration_mins'] || quizMeta['duration'] || '0') || m.durationMins,
        coinsReward:  parseInt(quizMeta['coins_reward']  || quizMeta['coins']     || '0') || m.coinsReward,
        status:       quizMeta['status'] || m.status,
      }))
      setStep('preview')
    } catch (e: any) { setParseError(e.message || 'Failed to parse file') }
  }

  const onDrop = (e: React.DragEvent) => { e.preventDefault(); setDragOver(false); const file = e.dataTransfer.files?.[0]; if (file) handleFile(file) }

  const submit = async () => {
    // Filter out rows where both question AND options are empty (user added extra blank rows)
    const cleanedQuestions = questions.filter(q => {
      const hasQuestion = (q.question || '').trim().length > 0
      const hasOptions = (q.option_a || '').trim().length > 0 && (q.option_b || '').trim().length > 0
      return hasQuestion && hasOptions
    })
    if (cleanedQuestions.length === 0) return

    const hasQuizTitle = cleanedQuestions.some(q => q.quiz_title?.trim())
    if (!hasQuizTitle && !meta.title.trim()) return
    if (!meta.subject.trim()) return
    setImporting(true)
    try {
      const hasQuizTitle = cleanedQuestions.some(q => q.quiz_title?.trim())
      if (hasQuizTitle) {
        // Group by quiz_title
        const groupMap: Record<string, any[]> = {}
        for (const q of cleanedQuestions) {
          const key = q.quiz_title?.trim() || meta.title || 'Untitled Quiz'
          if (!groupMap[key]) groupMap[key] = []
          const { quiz_title, ...rest } = q
          groupMap[key].push(rest)
        }
        const groups = Object.entries(groupMap).map(([title, qs]) => ({
          quiz: { ...meta, title, subject: majoritySubject(qs, meta.subject) },
          questions: qs,
        }))
        const res = await (api.quizzes as any).bulkImportMulti(groups)
        setResult({ multi: true, ...res.data })
      } else {
        const res = await (api.quizzes as any).bulkImport({ quiz: meta, questions: cleanedQuestions })
        setResult({ multi: false, ...res.data })
      }
      setStep('done')
      onSuccess()
    } catch (e: any) { setParseError(e.message || 'Import failed'); setImporting(false) }
  }

  const LETTERS = ['a', 'b', 'c', 'd', 'e']
  const isMultiMode = questions.some(q => q.quiz_title?.trim())
  const uniqueQuizTitles = Array.from(new Set(questions.map((q: any) => q.quiz_title).filter(Boolean)))
  const errors = questions.map((q, i) => {
    const msgs: string[] = []
    if (!q.question) msgs.push('question missing')
    const opts = [q.option_a, q.option_b, q.option_c, q.option_d, q.option_e].filter(Boolean)
    if (opts.length < 2) msgs.push('need >= 2 options')
    const co = String(q.correct_option || '').toLowerCase()
    if (!LETTERS.includes(co) && !['1', '2', '3', '4', '5'].includes(co)) msgs.push('correct_option invalid')
    // Match-type extra validation
    if ((q.question_subtype || '').toLowerCase() === 'match') {
      const l1 = [q.list1_a, q.list1_b].filter(Boolean)
      const l2 = [q.list2_1, q.list2_2].filter(Boolean)
      if (l1.length < 2) msgs.push('match: list1_a & list1_b required')
      if (l2.length < 2) msgs.push('match: list2_1 & list2_2 required')
    }
    return { row: i + 2, msgs }
  }).filter(e => e.msgs.length > 0)

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl">
        <div className="bg-gradient-to-r from-emerald-600 to-teal-500 px-6 py-5 rounded-t-3xl flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center"><FileSpreadsheet size={20} className="text-white" /></div>
            <div><h2 className="font-bold text-white text-lg leading-none">Bulk Quiz Import</h2><p className="text-white/70 text-xs mt-1">Upload Excel / CSV · max 500 questions</p></div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center"><X size={15} className="text-white" /></button>
        </div>

        <div className="overflow-y-auto flex-1 p-6">
          {step === 'upload' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <div>
                  <p className="font-semibold text-blue-800 text-sm">Download Template First</p>
                  <p className="text-xs text-blue-600 mt-0.5">Fill in the .xlsx template and upload it back</p>
                </div>
                <button onClick={downloadTemplate} className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors">
                  <Download size={13} /> Download .xlsx
                </button>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2">
                <p className="font-bold text-slate-700">Column Reference</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {[['quiz_title','Quiz name — groups rows into separate quizzes. Keep one subject per group.'],['question','The question text'],['option_a','First option (or combination choice A for match)'],['option_b','Second option (or combination choice B for match)'],['option_c','Third (optional)'],['option_d','Fourth (optional)'],['option_e','Fifth (optional)'],['correct_option','a/b/c/d/e or 1/2/3/4'],['explanation','Shown after answering (optional)'],['subject','Sets each quiz\'s subject by majority — split mixed-subject content into separate quiz_title groups'],['question_subtype','standard (default) or match — set to match for Match the Following questions'],['list1_a – list1_d','List-I items A/B/C/D for match questions (leave blank for standard MCQ)'],['list2_1 – list2_4','List-II items 1/2/3/4 for match questions (leave blank for standard MCQ)']].map(([col, desc]) => (
                    <div key={col} className="flex gap-1.5">
                      <code className="bg-white border border-slate-200 px-1.5 py-0.5 rounded text-emerald-700 font-mono shrink-0">{col}</code>
                      <span className="text-slate-500">{desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div onDragOver={e => { e.preventDefault(); setDragOver(true) }} onDragLeave={() => setDragOver(false)} onDrop={onDrop} onClick={() => fileRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-12 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${dragOver ? 'border-emerald-400 bg-emerald-50' : 'border-slate-300 hover:border-emerald-400 hover:bg-slate-50'}`}>
                <Upload size={32} className="text-slate-300" />
                <p className="font-semibold text-slate-600">Drop your Excel / CSV file here</p>
                <p className="text-xs text-slate-400">.xlsx .xls .csv · max 500 rows</p>
              </div>
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              {parseError && (<div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm"><AlertTriangle size={14} className="shrink-0" /> {parseError}</div>)}
            </div>
          )}

          {step === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="font-bold text-slate-800">{questions.length} questions parsed <span className="ml-2 text-xs font-normal text-slate-400">— click any cell to edit</span></p>
                {errors.length > 0
                  ? <span className="flex items-center gap-1.5 px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold"><AlertTriangle size={11} /> {errors.length} rows with errors</span>
                  : <span className="flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold"><CheckCircle2 size={11} /> All rows valid</span>}
              </div>

              {errors.length > 0 && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl space-y-1 max-h-24 overflow-y-auto">
                  {errors.map(e => <p key={e.row} className="text-xs text-red-700"><span className="font-bold">Row {e.row}:</span> {e.msgs.join(', ')}</p>)}
                </div>
              )}

              <div className="overflow-auto rounded-2xl border border-slate-200 max-h-96">
                <table className="w-full text-xs border-collapse">
                  <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="px-2 py-2.5 text-left font-bold text-slate-500 w-8">#</th>
                      {(() => {
                        const hasMatchQ = questions.some(q => (q.question_subtype || 'standard') === 'match')
                        const optCols = hasMatchQ ? ['Combo A','Combo B','Combo C','Combo D','E'] : ['A','B','C','D','E']
                        const base = questions.some(q => q.quiz_title) ? ['Quiz Title','Question','Type'] : ['Question','Type']
                        return [...base, ...optCols, 'Correct','Explanation','Subject',''].map(h => (
                          <th key={h} className={`px-2 py-2.5 text-left font-bold whitespace-nowrap ${h.startsWith('Combo') ? 'text-blue-500' : 'text-slate-500'}`}>{h}</th>
                        ))
                      })()}
                    </tr>
                  </thead>
                  <tbody>
                    {questions.map((q, i) => {
                      const hasError = errors.some(e => e.row === i + 2)
                      const isMatch = (q.question_subtype || 'standard') === 'match'
                      const update = (field: string, val: string) => setQuestions(prev => prev.map((row, idx) => idx === i ? { ...row, [field]: val } : row))
                      const cell = (field: string, placeholder = '', wide = false) => (
                        <td key={field} className={`p-0 border-r border-slate-100 ${wide ? 'min-w-48' : 'min-w-24'}`}>
                          <input value={q[field] || ''} onChange={e => update(field, e.target.value)} placeholder={placeholder}
                            className={`w-full px-2 py-1.5 text-xs bg-transparent outline-none focus:bg-blue-50 rounded ${field === 'correct_option' ? 'font-bold text-emerald-700 text-center' : 'text-slate-700'} ${hasError && !q[field] ? 'bg-red-50 placeholder:text-red-300' : ''}`} />
                        </td>
                      )
                      return (
                        <tr key={i} className={`border-b border-slate-100 group align-top ${hasError ? 'bg-red-50/40' : isMatch ? 'bg-blue-50/20 hover:bg-blue-50/40' : 'hover:bg-slate-50/60'}`}>
                          <td className="px-2 py-2 text-slate-400 font-mono text-center text-xs">{i + 1}</td>
                          {questions.some(q => q.quiz_title) && cell('quiz_title', 'Quiz title…', true)}

                          {/* Question cell — match rows embed List-I / List-II editors inline */}
                          <td key="question" className="p-0 border-r border-slate-100 min-w-56">
                            <input value={q.question || ''} onChange={e => update('question', e.target.value)} placeholder="Question…"
                              className={`w-full px-2 py-1.5 text-xs bg-transparent outline-none focus:bg-blue-50 rounded text-slate-700 ${hasError && !q.question ? 'bg-red-50 placeholder:text-red-300' : ''}`} />
                            {isMatch && (
                              <div className="px-2 pb-2 space-y-1">
                                <div className="grid grid-cols-2 gap-2 p-2 bg-white rounded-xl border border-blue-200">
                                  <div className="space-y-1">
                                    <p className="text-[9px] font-black text-blue-600 uppercase tracking-wider">List-I</p>
                                    {(['list1_a','list1_b','list1_c','list1_d'] as const).map((k, li) => (
                                      <div key={k} className="flex items-center gap-1">
                                        <span className="w-4 h-4 rounded flex items-center justify-center bg-blue-500 text-white text-[9px] font-black shrink-0">{['A','B','C','D'][li]}</span>
                                        <input value={q[k] || ''} onChange={e => update(k, e.target.value)}
                                          placeholder={`Item ${['A','B','C','D'][li]}…`}
                                          className={`flex-1 text-[10px] bg-blue-50 border rounded px-1.5 py-0.5 outline-none focus:border-blue-400 focus:bg-white text-slate-700 placeholder-slate-300 min-w-0 ${hasError && li < 2 && !q[k] ? 'border-red-300 bg-red-50' : 'border-blue-100'}`}
                                        />
                                      </div>
                                    ))}
                                  </div>
                                  <div className="space-y-1">
                                    <p className="text-[9px] font-black text-emerald-600 uppercase tracking-wider">List-II</p>
                                    {(['list2_1','list2_2','list2_3','list2_4'] as const).map((k, li) => (
                                      <div key={k} className="flex items-center gap-1">
                                        <span className="w-4 h-4 rounded flex items-center justify-center bg-emerald-500 text-white text-[9px] font-black shrink-0">{['1','2','3','4'][li]}</span>
                                        <input value={q[k] || ''} onChange={e => update(k, e.target.value)}
                                          placeholder={`Item ${['1','2','3','4'][li]}…`}
                                          className={`flex-1 text-[10px] bg-emerald-50 border rounded px-1.5 py-0.5 outline-none focus:border-emerald-400 focus:bg-white text-slate-700 placeholder-slate-300 min-w-0 ${hasError && li < 2 && !q[k] ? 'border-red-300 bg-red-50' : 'border-emerald-100'}`}
                                        />
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                <p className="text-[9px] text-blue-400 px-0.5">↓ Enter combination choices (A–D) below</p>
                              </div>
                            )}
                          </td>

                          {/* Type selector */}
                          <td key="question_subtype" className="p-0 border-r border-slate-100 min-w-24">
                            <select
                              value={q.question_subtype || 'standard'}
                              onChange={e => update('question_subtype', e.target.value)}
                              className={`w-full px-2 py-1.5 text-xs outline-none rounded cursor-pointer ${isMatch ? 'text-blue-600 font-bold bg-blue-50 focus:bg-blue-100' : 'text-slate-500 bg-transparent focus:bg-blue-50'}`}
                            >
                              <option value="standard">Standard</option>
                              <option value="match">🔗 Match</option>
                            </select>
                          </td>

                          {/* Option A–D: labelled "Combo" for match rows with blue tint */}
                          {(['option_a','option_b','option_c','option_d'] as const).map((key, oi) => (
                            <td key={key} className={`p-0 border-r border-slate-100 min-w-24 ${isMatch ? 'bg-blue-50/40' : ''}`}>
                              <input value={q[key] || ''} onChange={e => update(key, e.target.value)}
                                placeholder={isMatch ? `Combo ${['A','B','C','D'][oi]}…` : `${['A','B','C','D'][oi]}…`}
                                className={`w-full px-2 py-1.5 text-xs bg-transparent outline-none focus:bg-blue-50 rounded text-slate-700 ${hasError && oi < 2 && !q[key] ? 'bg-red-50 placeholder:text-red-300' : ''}`}
                              />
                            </td>
                          ))}
                          {cell('option_e', 'E')}
                          {cell('correct_option', 'a/b/c')}
                          {cell('explanation', 'Explanation…', true)}
                          {cell('subject', 'Subject')}
                          <td className="px-2 py-1.5">
                            <button onClick={() => setQuestions(prev => prev.filter((_, idx) => idx !== i))}
                              className="opacity-0 group-hover:opacity-100 w-6 h-6 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center transition-all">
                              <X size={11} className="text-red-400" />
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              {/* Add Row removed — blank rows caused validation errors on import.
                  Use Excel/CSV upload to add more questions, or use the delete ✕ on each row. */}

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3">
                <p className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                  {questions.some(q => q.quiz_title)
                    ? `Quiz Details — ${uniqueQuizTitles.length} quizzes detected from quiz_title column`
                    : 'Quiz Details — from your sheet'}
                </p>
                {questions.some(q => q.quiz_title) && (
                  <>
                    <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-700">
                      Titles are taken from the <code className="font-mono bg-white px-1 rounded">quiz_title</code> column. Type, duration, coins and status below apply to every quiz. Subject is decided per quiz from the rows' own <code className="font-mono bg-white px-1 rounded">subject</code> column — see the breakdown below.
                    </div>
                    {/* Per-quiz subject preview — shows exactly what will be created,
                        and flags groups whose rows span more than one subject so the
                        admin can fix the offending cells above before importing. */}
                    <div className="space-y-1.5">
                      {uniqueQuizTitles.map(title => {
                        const qs = questions.filter(q => (q.quiz_title || '').trim() === title)
                        const subj = majoritySubject(qs, meta.subject)
                        const distinct = distinctSubjects(qs)
                        const mixed = distinct.length > 1
                        return (
                          <div key={title} className="flex items-center justify-between gap-2 px-3 py-2 bg-white rounded-xl border border-emerald-100 text-xs">
                            <span className="font-semibold text-slate-700 truncate">{title} <span className="text-slate-400 font-normal">· {qs.length} Qs</span></span>
                            <span className="flex items-center gap-1.5 shrink-0">
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-bold">{subj || '—'}</span>
                              {mixed && (
                                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-bold" title={`Rows have different subjects: ${distinct.join(', ')}`}>
                                  <AlertTriangle size={10} /> mixed: {distinct.join(', ')}
                                </span>
                              )}
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </>
                )}
                <div className="grid grid-cols-2 gap-2">
                  {!questions.some(q => q.quiz_title) && (
                    <div className="col-span-2"><label className="block text-[10px] font-bold text-slate-500 mb-1">Title *</label><input value={meta.title} onChange={e => setMeta(m => ({ ...m, title: e.target.value }))} placeholder="Quiz title" className="input w-full text-sm" /></div>
                  )}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">
                      {questions.some(q => q.quiz_title) ? 'Fallback Subject' : 'Subject *'}
                    </label>
                    <input value={meta.subject} onChange={e => setMeta(m => ({ ...m, subject: e.target.value }))} placeholder="Subject" className="input text-sm w-full" />
                    {questions.some(q => q.quiz_title) && (
                      <p className="text-[10px] text-slate-400 mt-1">Only used for a quiz whose rows have no subject set — see breakdown above.</p>
                    )}
                  </div>
                  <div><label className="block text-[10px] font-bold text-slate-500 mb-1">Type</label><select value={meta.type} onChange={e => setMeta(m => ({ ...m, type: e.target.value }))} className="input text-sm w-full"><option value="topic">Topic</option><option value="mock">Mock Test</option><option value="daily">Daily</option></select></div>
                  <div><label className="block text-[10px] font-bold text-slate-500 mb-1">Duration (mins)</label><input type="number" value={meta.durationMins} onChange={e => setMeta(m => ({ ...m, durationMins: +e.target.value }))} className="input text-sm w-full" min={1} /></div>
                  <div><label className="block text-[10px] font-bold text-slate-500 mb-1">Coins Reward</label><input type="number" value={meta.coinsReward} onChange={e => setMeta(m => ({ ...m, coinsReward: +e.target.value }))} className="input text-sm w-full" min={0} /></div>
                  <div><label className="block text-[10px] font-bold text-slate-500 mb-1">Status</label><select value={meta.status} onChange={e => setMeta(m => ({ ...m, status: e.target.value }))} className="input text-sm w-full"><option value="published">Published</option><option value="draft">Draft</option></select></div>
                  <div className="col-span-2 flex items-center gap-2 pt-1">
                    <input type="checkbox" id="bulkNegMarking" checked={meta.negativeMarkingEnabled}
                      onChange={e => setMeta(m => ({ ...m, negativeMarkingEnabled: e.target.checked }))} className="w-4 h-4 accent-red-500" />
                    <label htmlFor="bulkNegMarking" className="text-xs font-bold text-slate-600">⚠️ Enable Negative Marking</label>
                  </div>
                  {meta.negativeMarkingEnabled && (
                    <>
                      <div><label className="block text-[10px] font-bold text-slate-500 mb-1">✅ Marks / Correct</label><input type="number" step={0.25} value={meta.marksPerCorrect} onChange={e => setMeta(m => ({ ...m, marksPerCorrect: +e.target.value }))} className="input text-sm w-full" min={0.25} placeholder="2" /></div>
                      <div><label className="block text-[10px] font-bold text-slate-500 mb-1">❌ Marks / Wrong</label><input type="number" step={0.01} value={meta.marksPerWrong} onChange={e => setMeta(m => ({ ...m, marksPerWrong: +e.target.value }))} className="input text-sm w-full" min={0} placeholder="0.66" /></div>
                    </>
                  )}
                </div>
              </div>

              {parseError && (<div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm"><AlertTriangle size={14} className="shrink-0" /> {parseError}</div>)}

              <div className="flex gap-2 justify-end">
                <button onClick={() => { setStep('upload'); setQuestions([]) }} className="btn-secondary text-sm">Re-upload</button>
                <button onClick={submit} disabled={importing || (!isMultiMode && !meta.title.trim()) || !meta.subject.trim()} className="btn-primary text-sm disabled:opacity-40 min-w-44">
                  {importing ? <><Loader2 size={14} className="animate-spin" /> Importing…</> : questions.some(q => q.quiz_title)
                    ? <><Upload size={14} /> Import {uniqueQuizTitles.length} Quizzes ({questions.length} Qs)</>
                    : <><Upload size={14} /> Import {questions.length} Questions</>}
                </button>
              </div>
            </div>
          )}

          {step === 'done' && result && (
            <div className="flex flex-col items-center py-10 gap-4 text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center"><CheckCircle2 size={32} className="text-green-600" /></div>
              <div>
                <p className="text-xl font-black text-slate-800">Import Successful!</p>
                {result.multi ? (
                  <div className="mt-2 space-y-1">
                    <p className="text-slate-500"><span className="font-bold text-emerald-600">{result.totalQuizzes}</span> quizzes created with <span className="font-bold text-emerald-600">{result.totalQuestions}</span> total questions</p>
                    <div className="mt-3 text-left space-y-1 max-h-40 overflow-y-auto">
                      {result.quizzes?.map((q: any, i: number) => (
                        <div key={i} className="flex items-center justify-between px-3 py-1.5 bg-slate-50 rounded-lg text-xs">
                          <span className="font-medium text-slate-700">{q.title}</span>
                          <span className="text-emerald-600 font-bold">{q.questionsInserted} Qs</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-slate-500 mt-1"><span className="font-bold text-emerald-600">{result.questionsInserted}</span> questions added to <span className="font-bold text-slate-700">"{result.title}"</span></p>
                )}
              </div>
              <button onClick={onClose} className="btn-primary mt-2">Done</button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function MatchQuestionEditor({ q, qi, updateQ }: { q: any; qi: number; updateQ: (i: number, key: string, val: any) => void }) {
  const updateList1 = (idx: number, text: string) => {
    const updated = q.matchList1.map((item: any, i: number) => i === idx ? { ...item, text } : item)
    updateQ(qi, 'matchList1', updated)
  }
  const updateList2 = (idx: number, text: string) => {
    const updated = q.matchList2.map((item: any, i: number) => i === idx ? { ...item, text } : item)
    updateQ(qi, 'matchList2', updated)
  }
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">List-I</p>
          {q.matchList1.map((item: any, idx: number) => (
            <div key={idx} className="flex items-center gap-2">
              <span className="w-6 h-6 flex items-center justify-center rounded-lg bg-blue-100 text-blue-700 text-xs font-bold shrink-0">{item.label}</span>
              <input
                value={item.text}
                onChange={e => updateList1(idx, e.target.value)}
                placeholder={`Item ${item.label}…`}
                className="input flex-1 text-sm"
              />
            </div>
          ))}
        </div>
        <div className="space-y-1.5">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">List-II</p>
          {q.matchList2.map((item: any, idx: number) => (
            <div key={idx} className="flex items-center gap-2">
              <span className="w-6 h-6 flex items-center justify-center rounded-lg bg-emerald-100 text-emerald-700 text-xs font-bold shrink-0">{item.label}</span>
              <input
                value={item.text}
                onChange={e => updateList2(idx, e.target.value)}
                placeholder={`Item ${item.label}…`}
                className="input flex-1 text-sm"
              />
            </div>
          ))}
        </div>
      </div>
      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
        <p className="text-[10px] font-bold text-slate-500 mb-1.5">Preview</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-700">
          {q.matchList1.filter((i: any) => i.text).map((item: any, idx: number) => {
            const pair = q.matchList2[idx]
            return <div key={idx} className="flex gap-1"><span className="font-bold text-blue-600">{item.label}.</span> {item.text} <span className="text-slate-400 mx-1">↔</span> <span className="font-bold text-emerald-600">{pair?.label}.</span> {pair?.text}</div>
          })}
        </div>
      </div>
    </div>
  )
}

export default function QuizzesPage() {
  const { showToast, ToastComponent } = useToast()

  // List state
  const [quizzes, setQuizzes] = useState<any[]>([])
  const [total, setTotal]     = useState(0)
  const [loading, setLoading] = useState(true)
  const [search, setSearch]   = useState('')
  const [typeFilter, setType] = useState('')
  const [page, setPage]       = useState(1)
  const debouncedSearch       = useDebounce(search, 400)

  // Modal state
  const [showModal, setShowModal]   = useState(false)
  const [showQModal, setShowQModal] = useState(false)
  const [showBulk, setShowBulk]     = useState(false)
  const [editing, setEditing]       = useState<any>(null)
  const [selectedQuiz, setSelectedQuiz] = useState<any>(null)
  const [form, setForm]             = useState<any>(EMPTY_FORM)
  const [questions, setQuestions]   = useState<any[]>([emptyQ()])

  // Issue 10: existing questions for edit
  const [existingQuestions, setExistingQuestions] = useState<any[]>([])
  const [loadingQs, setLoadingQs]   = useState(false)
  const [editingQId, setEditingQId] = useState<string|null>(null)
  const [editQForm, setEditQForm]   = useState<any>(null)
  const [savingQ2, setSavingQ2]     = useState(false)
  const [qTab, setQTab]             = useState<'existing'|'add'>('existing')

  const { data: examsData } = useApiData<any>(() => api.exams.list(), [])
  const examOptions: any[] = examsData?.exams || []

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api.quizzes.list({ search: debouncedSearch, type: typeFilter, page, limit: LIMIT })
      setQuizzes(res.data?.quizzes || [])
      // Issue 4: total from API not local count
      setTotal(res.meta?.total ?? res.data?.total ?? res.data?.quizzes?.length ?? 0)
    } catch (e: any) { showToast(e.message || 'Failed to load', 'error') }
    finally { setLoading(false) }
  }, [debouncedSearch, typeFilter, page])

  useEffect(() => { setPage(1) }, [debouncedSearch, typeFilter])
  useEffect(() => { load() }, [load])

  // Issue 10: load existing questions when opening Q modal
  const openQuestions = async (quiz: any) => {
    setSelectedQuiz(quiz)
    setQuestions([emptyQ()])
    setShowQModal(true)
    setQTab('existing')
    setLoadingQs(true)
    try {
      const res = await api.quizzes.getQuestions?.(quiz.id)
      setExistingQuestions(res?.data?.questions || [])
    } catch { setExistingQuestions([]) }
    finally { setLoadingQs(false) }
  }

  const { mutate: save, loading: saving } = useMutation(
    (d: any) => editing ? api.quizzes.update(editing.id, d) : api.quizzes.create(d),
    {
      onSuccess: () => { setShowModal(false); load(); showToast(editing ? 'Quiz updated ✅' : 'Quiz created ✅') },
      onError: (msg) => showToast(msg, 'error'),
    }
  )

  const { mutate: saveQuestions, loading: savingQ } = useMutation(
    (args: any) => api.quizzes.addQuestions(args.id, args.qs),
    {
      onSuccess: () => { setShowQModal(false); load(); showToast('Questions saved ✅') },
      onError: (msg) => showToast(msg, 'error'),
    }
  )

  // Issue 6: delete calls actual delete, not status=rejected
  const { mutate: remove } = useMutation(
    (id: string) => api.quizzes.delete(id),
    { onSuccess: () => { load(); showToast('Quiz deleted') }, onError: (m) => showToast(m, 'error') }
  )

  const openNew  = () => { setEditing(null); setForm(EMPTY_FORM); setShowModal(true) }
  const openEdit = (q: any) => {
    setEditing(q)
    setForm({
      title: q.title, subject: q.subject, type: q.type,
      totalQuestions: q.total_questions, durationMins: q.duration_mins,
      coinsReward: q.coins_reward,
      status: q.status, scheduledFor: q.scheduled_for ? q.scheduled_for.split('T')[0] : '',
      examTags: q.exam_tags || [],
      negativeMarkingEnabled: q.negative_marking_enabled === true,
      marksPerCorrect: q.marks_per_correct != null ? +q.marks_per_correct : 1,
      marksPerWrong:   q.marks_per_wrong   != null ? +q.marks_per_wrong   : 0,
      shuffleQuestions: q.shuffle_questions !== false,
      shuffleOptions:   q.shuffle_options   !== false,
      isExamMode:       q.is_exam_mode === true,
    })
    setShowModal(true)
  }

  // Question helpers
  const updateQ = (i: number, key: string, val: any) =>
    setQuestions(prev => prev.map((q, idx) => idx === i ? { ...q, [key]: val } : q))

  const updateOption = (qi: number, oi: number, val: string) =>
    setQuestions(prev => prev.map((q, idx) => {
      if (idx !== qi) return q
      const opts = [...q.options]; opts[oi] = val; return { ...q, options: opts }
    }))

  const setOptionCount = (qi: number, cnt: number) =>
    setQuestions(prev => prev.map((q, idx) => {
      if (idx !== qi) return q
      const opts = Array(cnt).fill('').map((_, i) => q.options[i] || '')
      const imgs = Array(cnt).fill('').map((_, i) => q.optionImages[i] || '')
      const correct = q.correctOption >= cnt ? 0 : q.correctOption
      return { ...q, options: opts, optionImages: imgs, optionCount: cnt, correctOption: correct }
    }))

  const handleSaveQuestions = () => {
    const valid = questions.filter(q => q.question.trim() && q.options.filter(Boolean).length >= 2)
    if (!valid.length) { showToast('Each question needs text and at least 2 options', 'error'); return }

    // Transform to backend format: optionA/B/C/D + correctOption as letter
    const transformed = valid.map(q => {
      const opts = [...q.options]
      while (opts.length < 4) opts.push('')
      const letters = ['a', 'b', 'c', 'd', 'e']
      const isMatch = q.questionSubtype === 'match'
      return {
        question:          q.question,
        questionType:      q.questionType || 'text',
        optionA:           opts[0] || '',
        optionB:           opts[1] || '',
        optionC:           opts[2] || '',
        optionD:           opts[3] || '',
        correctOption:     letters[q.correctOption ?? 0] || 'a',
        explanation:       q.explanation || '',
        questionSubtype:   isMatch ? 'match' : 'standard',
        matchData:         isMatch ? {
          list1: q.matchList1.filter((i: any) => i.text.trim()),
          list2: q.matchList2.filter((i: any) => i.text.trim()),
        } : null,
      }
    })
    saveQuestions({ id: selectedQuiz.id, qs: transformed })
  }

  const totalPages = Math.ceil(total / LIMIT)

  // Stats — issue 4: from loaded data
  const stats = [
    { label:'Daily',   value:quizzes.filter(q=>q.type==='daily').length, emoji:'🎯', color:'text-purple-600 bg-purple-50' },
    { label:'Topic',   value:quizzes.filter(q=>q.type==='topic').length, emoji:'📚', color:'text-blue-600 bg-blue-50' },
    { label:'Mock',    value:quizzes.filter(q=>q.type==='mock').length,  emoji:'📝', color:'text-orange-600 bg-orange-50' },
    { label:'Attempts (page)', value:formatNumber(quizzes.reduce((a,q)=>a+(q.attempt_count||0),0)), emoji:'👥', color:'text-green-600 bg-green-50' },
  ]

  return (
    <div className="min-h-screen">
      {ToastComponent}
      <Header title="Quizzes & Mock Tests" subtitle="Manage all quizzes, topic tests and mock exams" />

      <div className="p-6 space-y-5 animate-fade-in">

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map(s => (
            <div key={s.label} className={`card p-4 flex items-center gap-3 ${s.color.split(' ')[1]}`}>
              <span className="text-2xl">{s.emoji}</span>
              <div>
                <p className={`text-xl font-black ${s.color.split(' ')[0]}`}>{s.value}</p>
                <p className="text-xs text-slate-500 font-medium">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filters — Issue 2: debounced search actually filters */}
        <div className="card p-4 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-52">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1) }}
              placeholder="Search quizzes…" className="input pl-9" />
          </div>
          {/* Issue 1+3: uniform filter pill */}
          <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-50 rounded-xl border border-slate-200">
            <Filter size={12} className="text-slate-400" />
            <select value={typeFilter} onChange={e => { setType(e.target.value); setPage(1) }}
              className="text-sm bg-transparent outline-none text-slate-700 pr-1">
              <option value="">All Types</option>
              <option value="daily">Daily</option>
              <option value="topic">Topic</option>
              <option value="mock">Mock Test</option>
            </select>
          </div>
          <button onClick={load} className="btn-secondary px-3 py-2" title="Refresh"><RefreshCw size={13} /></button>
          <button onClick={() => setShowBulk(true)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition-colors"><FileSpreadsheet size={14} /> Bulk Import</button>
          <button onClick={openNew} className="btn-primary"><Plus size={14} /> Add Quiz</button>
        </div>

        {showBulk && (
          <BulkQuizUpload
            onClose={() => setShowBulk(false)}
            onSuccess={() => { load(); setShowBulk(false) }}
          />
        )}

        {/* List — Issue 3: card grid instead of table */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {[1,2,3].map(i => <div key={i} className="card p-5 animate-pulse h-40"><div className="h-4 bg-slate-100 rounded w-3/4 mb-3"/><div className="h-3 bg-slate-100 rounded w-1/2"/></div>)}
          </div>
        ) : quizzes.length === 0 ? (
          <div className="card p-16 text-center">
            <HelpCircle size={40} className="mx-auto mb-4 text-slate-200"/>
            <p className="font-bold text-slate-800 text-lg mb-1">No quizzes found</p>
            <p className="text-sm text-slate-400 mb-5">Create your first quiz to get started</p>
            <button onClick={openNew} className="btn-primary mx-auto"><Plus size={14}/> Create Quiz</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {quizzes.map(quiz => {
              const meta = TYPE_META[quiz.type] || TYPE_META.topic
              return (
                <div key={quiz.id} className="card p-0 overflow-hidden hover:shadow-lg transition-shadow flex flex-col">
                  {/* Type color bar */}
                  <div className={`h-1 w-full ${quiz.type==='daily'?'bg-purple-200':quiz.type==='mock'?'bg-orange-200':'bg-blue-200'}`}/>
                  <div className="p-5 flex flex-col gap-3 flex-1">
                    {/* Title + badges */}
                    <div>
                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${meta.bg.replace('100','50')} ${meta.color.replace('700','600')}`}>{meta.label}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${quiz.status==='published'?'bg-green-50 text-green-700 border-green-200':'bg-slate-50 text-slate-500 border-slate-200'}`}>
                          {quiz.status}
                        </span>
                        {quiz.negative_marking_enabled && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border bg-red-50 text-red-600 border-red-200" title={`-${quiz.marks_per_wrong} per wrong answer`}>
                            ⚠️ -{quiz.marks_per_wrong}
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">{quiz.title}</h3>
                      {quiz.subject && <p className="text-xs text-slate-500 mt-0.5">{quiz.subject}</p>}
                    </div>

                    {/* Stats grid */}
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { icon:<BookOpen size={11}/>,  label:'Qs',       value:quiz.total_questions||0 },
                        { icon:<Clock size={11}/>,     label:'Mins',     value:quiz.duration_mins||0 },
                        { icon:<span className="text-[11px]">🪙</span>, label:'Coins', value:quiz.coins_reward||0 },
                        { icon:<Target size={11}/>,    label:'Attempts', value:formatNumber(quiz.attempt_count||0) },
                      ].map(s => (
                        <div key={s.label} className="flex flex-col items-center py-2 bg-slate-50/80 rounded-xl border border-slate-100">
                          <span className="text-slate-400 mb-0.5">{s.icon}</span>
                          <span className="text-xs font-bold text-slate-800">{s.value}</span>
                          <span className="text-[9px] text-slate-400">{s.label}</span>
                        </div>
                      ))}
                    </div>

                    {/* Avg score bar */}
                    {(quiz.avg_score > 0) && (
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-[10px] text-slate-400">Avg Score</span>
                          <span className="text-[10px] font-bold text-slate-700">{parseFloat(quiz.avg_score||0).toFixed(0)}%</span>
                        </div>
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-brand-500 rounded-full" style={{width:`${quiz.avg_score||0}%`}}/>
                        </div>
                      </div>
                    )}

                    <div className="flex-1"/>

                    {/* Actions */}
                    <div className="flex gap-2 pt-2 border-t border-slate-50">
                      <button onClick={() => openQuestions(quiz)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-green-50 hover:bg-green-100 text-green-700 text-xs font-semibold transition-colors">
                        <ListPlus size={12}/> Questions
                      </button>
                      <button onClick={() => openEdit(quiz)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold transition-colors">
                        <Edit size={12}/> Edit
                      </button>
                      <button onClick={() => { if (confirm('Delete this quiz?')) remove(quiz.id) }}
                        className="w-9 h-9 rounded-xl bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors">
                        <Trash2 size={13} className="text-red-500"/>
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Issue 1: Pagination */}
        {total > LIMIT && (
          <div className="card px-5 py-4 flex items-center justify-between flex-wrap gap-3">
            <p className="text-sm text-slate-500">
              Showing <b>{Math.min((page-1)*LIMIT+1,total)}</b>–<b>{Math.min(page*LIMIT,total)}</b> of <b>{total}</b>
            </p>
            <div className="flex items-center gap-1.5">
              <button disabled={page===1} onClick={()=>setPage(1)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-100 disabled:opacity-30 transition-colors">«</button>
              <button disabled={page===1} onClick={()=>setPage(p=>p-1)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-100 disabled:opacity-30 transition-colors"><ChevronLeft size={14}/></button>
              {Array.from({length:Math.min(totalPages,7)},(_,i)=>{const p=totalPages<=7?i+1:page<=4?i+1:page>=totalPages-3?totalPages-6+i:page-3+i;return <button key={p} onClick={()=>setPage(p)} className={`w-8 h-8 rounded-lg text-sm font-semibold ${p===page?'bg-brand-500 text-white':'text-slate-500 hover:bg-slate-100'}`}>{p}</button>})}
              <button disabled={page>=totalPages} onClick={()=>setPage(p=>p+1)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-100 disabled:opacity-30 transition-colors"><ChevronRight size={14}/></button>
              <button disabled={page>=totalPages} onClick={()=>setPage(totalPages)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-100 disabled:opacity-30 transition-colors">»</button>
            </div>
          </div>
        )}
      </div>

      {/* ════════════════ CREATE / EDIT QUIZ MODAL ════════════════ */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg max-h-[92vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>

            {/* Header */}
            <div className="bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-5 flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-white text-lg">{editing ? 'Edit Quiz' : 'Create Quiz'}</h3>
                <p className="text-white/60 text-xs mt-0.5">{editing ? 'Update quiz details' : 'Fill in the details — questions added separately'}</p>
              </div>
              <button onClick={() => setShowModal(false)} className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center">
                <X size={15} className="text-white"/>
              </button>
            </div>

            <div className="overflow-y-auto flex-1 p-6 space-y-4">

              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">Quiz Title *</label>
                <input value={form.title} onChange={e => setForm({...form,title:e.target.value})}
                  className="input w-full" placeholder="e.g. BPSC Polity Practice Set #1" autoFocus />
              </div>

              {/* Type + Subject */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5">Type</label>
                  <div className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <select value={form.type} onChange={e => setForm({...form,type:e.target.value})}
                      className="text-sm bg-transparent outline-none text-slate-700 w-full">
                      <option value="daily">🎯 Daily Quiz</option>
                      <option value="topic">📚 Topic Quiz</option>
                      <option value="mock">📝 Mock Test</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5">Subject</label>
                  <DynamicSelect type="subjects" value={form.subject} onChange={v => setForm({...form,subject:v})} placeholder="Select Subject" />
                </div>
              </div>

              {/* Issue 5: Numbers with proper padding selects */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5">Duration (mins)</label>
                  <NumInput value={form.durationMins} onChange={v => setForm({...form,durationMins:v})} min={1} max={180} placeholder="15" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5">🪙 Coins Reward</label>
                  <NumInput value={form.coinsReward} onChange={v => setForm({...form,coinsReward:v})} min={0} placeholder="10" />
                </div>
              </div>

              {/* Negative Marking — admin-configurable per test, applies to
                  Daily Quiz / Topic & Subject-wise / Mock & Full-Length tests
                  alike since they all share this same quiz record. */}
              <div className="rounded-2xl border-2 border-slate-200 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 bg-slate-50">
                  <label className="flex items-center gap-2.5 cursor-pointer select-none"
                    onClick={() => setForm({...form, negativeMarkingEnabled: !form.negativeMarkingEnabled})}>
                    <div className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${form.negativeMarkingEnabled ? 'bg-red-500' : 'bg-slate-200'}`}>
                      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form.negativeMarkingEnabled ? 'translate-x-5' : 'translate-x-0.5'}`}/>
                    </div>
                    <span className="text-sm font-bold text-slate-700">⚠️ Negative Marking</span>
                  </label>
                  {form.negativeMarkingEnabled && (
                    <span className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-1 rounded-full">ON</span>
                  )}
                </div>
                {form.negativeMarkingEnabled && (
                  <div className="p-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">✅ Marks / Correct</label>
                        <DecimalInput value={form.marksPerCorrect} onChange={v => setForm({...form,marksPerCorrect:v})} min={0.25} max={20} step={0.25} placeholder="2" />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">❌ Marks / Wrong</label>
                        <DecimalInput value={form.marksPerWrong} onChange={v => setForm({...form,marksPerWrong:v})} min={0} max={20} step={0.01} placeholder="0.66" />
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-500 bg-white border border-slate-200 rounded-xl px-3 py-2">
                      Correct answer: <span className="font-bold text-emerald-600">+{form.marksPerCorrect || 0}</span> marks · Wrong answer: <span className="font-bold text-red-600">-{form.marksPerWrong || 0}</span> marks · Unanswered: <span className="font-bold text-slate-600">0</span> marks
                    </p>
                  </div>
                )}
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">Status</label>
                <div className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <select value={form.status} onChange={e => setForm({...form,status:e.target.value})}
                    className="text-sm bg-transparent outline-none text-slate-700 w-full">
                    <option value="published">Published — visible in app</option>
                    <option value="draft">Draft — hidden</option>
                  </select>
                </div>
              </div>

              {/* Shuffle */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-600">Shuffle</label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.shuffleQuestions} onChange={e => setForm({...form,shuffleQuestions:e.target.checked})} className="w-4 h-4 accent-brand-500"/>
                  <span className="text-sm text-slate-700">Shuffle question order</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.shuffleOptions} onChange={e => setForm({...form,shuffleOptions:e.target.checked})} className="w-4 h-4 accent-brand-500"/>
                  <span className="text-sm text-slate-700">Shuffle option order</span>
                </label>
              </div>

              {/* Exam Mode */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-600">Exam Mode</label>
                <label className="flex items-center gap-2 cursor-pointer" onClick={() => setForm({...form, isExamMode: !form.isExamMode})}>
                  <div className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${form.isExamMode ? 'bg-blue-600' : 'bg-slate-200'}`}>
                    <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form.isExamMode ? 'translate-x-5' : 'translate-x-0.5'}`}/>
                  </div>
                  <span className="text-sm text-slate-700">Enable Exam Mode</span>
                </label>
                {form.isExamMode && (
                  <p className="text-[11px] text-blue-600">Screen stays on, status bar hidden during test.</p>
                )}
              </div>

              {/* Exam Tags — optional. Leave empty to show this quiz to
                  everyone regardless of which exam they selected at
                  onboarding (e.g. daily/general GK quizzes). Select one
                  or more exams to restrict it to users preparing for
                  those exams (e.g. exam-specific mock tests). */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Exam Tags <span className="font-normal text-slate-400">(optional)</span>
                </label>
                <p className="text-[11px] text-slate-400 mb-2">
                  Leave empty to show this quiz to everyone. Select exams to show it only to users preparing for those exams.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {examOptions.map((exam: any) => {
                    const selected = form.examTags.includes(exam.name)
                    return (
                      <button
                        key={exam.id}
                        type="button"
                        onClick={() => setForm({
                          ...form,
                          examTags: selected
                            ? form.examTags.filter((t: string) => t !== exam.name)
                            : [...form.examTags, exam.name]
                        })}
                        className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors
                          ${selected ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-slate-600 border-slate-200 hover:border-brand-300'}`}
                      >
                        {exam.emoji} {exam.name}
                      </button>
                    )
                  })}
                  {examOptions.length === 0 && (
                    <p className="text-xs text-slate-400">No exams configured yet.</p>
                  )}
                </div>
                {form.examTags.length > 0 && (
                  <button type="button" onClick={() => setForm({...form, examTags: []})}
                    className="mt-2 text-[11px] text-slate-400 hover:text-slate-600 underline">
                    Clear — show to everyone
                  </button>
                )}
              </div>

              {/* Scheduled date for daily */}
              {form.type === 'daily' && (
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5">Scheduled For</label>
                  <input type="date" value={form.scheduledFor||''} onChange={e => setForm({...form,scheduledFor:e.target.value})} className="input w-full" />
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-3 bg-slate-50/50 shrink-0">
              <button onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button onClick={() => save({...form, scheduledFor:form.scheduledFor?.trim()||null})}
                disabled={saving || !form.title.trim()}
                className="btn-primary disabled:opacity-40">
                {saving ? <><Loader2 size={14} className="animate-spin"/> Saving…</> : editing ? 'Update Quiz' : 'Create Quiz →'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ QUESTIONS MODAL ════════════════ */}
      {showQModal && selectedQuiz && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowQModal(false)}>
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl max-h-[94vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>

            {/* Header */}
            <div className="bg-gradient-to-r from-green-700 to-green-500 px-6 py-4 flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-white">Questions — {selectedQuiz.title}</h3>
                <p className="text-white/60 text-xs mt-0.5">
                  Target: {selectedQuiz.total_questions} questions ·
                  {existingQuestions.length} existing
                </p>
              </div>
              <button onClick={() => setShowQModal(false)} className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center">
                <X size={15} className="text-white"/>
              </button>
            </div>

            {/* Tabs: Issue 10 */}
            <div className="flex border-b border-slate-100 px-6 shrink-0">
              {(['existing','add'] as const).map(t => (
                <button key={t} onClick={() => setQTab(t)}
                  className={`py-3 px-4 text-sm font-semibold border-b-2 -mb-px transition-colors
                    ${qTab===t?'border-brand-500 text-brand-700':'border-transparent text-slate-500 hover:text-slate-700'}`}>
                  {t === 'existing'
                    ? `📋 Existing (${loadingQs ? '…' : existingQuestions.length})`
                    : `➕ Add New`}
                </button>
              ))}
            </div>

            <div className="overflow-y-auto flex-1 p-5">

              {/* Issue 10: Existing questions tab */}
              {qTab === 'existing' && (
                <div className="space-y-3">
                  {loadingQs ? (
                    <div className="py-12 text-center"><Loader2 size={24} className="animate-spin mx-auto text-slate-300"/></div>
                  ) : existingQuestions.length === 0 ? (
                    <div className="py-12 text-center">
                      <HelpCircle size={32} className="mx-auto mb-3 text-slate-200"/>
                      <p className="text-slate-400 font-medium">No questions added yet</p>
                      <button onClick={() => setQTab('add')} className="btn-primary mt-3 text-sm">Add Questions →</button>
                    </div>
                  ) : (
                    existingQuestions.map((q: any, i: number) => {
                      const correctIdx = normCorrect(q.correct_option ?? q.correctOption)
                      // Only show options that have actual content (not empty string)
                      const allOpts = [q.option_a, q.option_b, q.option_c, q.option_d]
                      const opts = allOpts.filter(o => typeof o === 'string' && o.trim() !== '')
                      const optCount = opts.length || 2
                      const isEditing = editingQId === (q.id || String(i))

                      return (
                        <div key={q.id || i} className="rounded-2xl border-2 border-slate-200 overflow-hidden">
                          {/* Question header */}
                          <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-100">
                            <span className="text-xs font-black text-slate-500">Q{i+1}</span>
                            <div className="flex gap-1.5">
                              {!isEditing && (
                                <button
                                  onClick={() => {
                                    setEditingQId(q.id || String(i))
                                    const qOptCount = [q.option_a, q.option_b, q.option_c, q.option_d]
                                      .filter(o => typeof o === 'string' && o.trim() !== '').length || 2
                                    setEditQForm({
                                      question: q.question_text || q.question || '',
                                      optionA: q.option_a || '',
                                      optionB: q.option_b || '',
                                      optionC: q.option_c || '',
                                      optionD: q.option_d || '',
                                      correctOption: correctIdx,
                                      explanation: q.explanation || '',
                                      optionCount: qOptCount,
                                      difficulty: q.difficulty || 'medium',
                                      topicTag: q.topic_tag || '',
                                    })
                                  }}
                                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 text-xs font-semibold rounded-lg transition-colors"
                                >
                                  <Edit size={11}/> Edit
                                </button>
                              )}
                              <button
                                onClick={async () => {
                                  if (!confirm('Delete this question?')) return
                                  try {
                                    await api.quizzes.deleteQuestion(q.id)
                                    setExistingQuestions(prev => prev.filter((_,idx) => idx !== i))
                                    showToast('Question deleted')
                                  } catch (e: any) { showToast(e.message || 'Failed', 'error') }
                                }}
                                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold rounded-lg transition-colors"
                              >
                                <Trash2 size={11}/> Delete
                              </button>
                            </div>
                          </div>

                          <div className="p-4">
                            {isEditing ? (
                              /* ── Edit mode ── */
                              <div className="space-y-3">
                                <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1">Question *</label>
                                  <textarea
                                    value={editQForm.question}
                                    onChange={e => setEditQForm({...editQForm, question: e.target.value})}
                                    className="input resize-none h-16 w-full" autoFocus
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1">Options — click letter to mark correct</label>
                                  <div className="space-y-2">
                                    {/* Option count selector */}
                                  <div className="flex items-center gap-1.5 mb-2">
                                    <span className="text-[10px] text-slate-500 font-medium">Options:</span>
                                    {[2,3,4].map(n => (
                                      <button key={n} onClick={() => {
                                        const keys = ['optionA','optionB','optionC','optionD']
                                        const update: any = { ...editQForm, optionCount: n }
                                        // Clear options beyond new count
                                        keys.slice(n).forEach(k => { update[k] = '' })
                                        // Cap correctOption within new range
                                        if (update.correctOption >= n) update.correctOption = 0
                                        setEditQForm(update)
                                      }}
                                        className={`w-7 h-7 rounded-lg text-xs font-bold transition-colors
                                          ${(editQForm.optionCount||4)===n?'bg-brand-500 text-white':'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                                        {n}
                                      </button>
                                    ))}
                                  </div>
                                  {['A','B','C','D'].slice(0, editQForm.optionCount || 4).map((lbl, oi) => {
                                      const key = `option${lbl}` as 'optionA'|'optionB'|'optionC'|'optionD'
                                      const isCorrect = editQForm.correctOption === oi
                                      return (
                                        <div key={oi} className={`flex items-center gap-2 p-2 rounded-xl border-2 transition-colors
                                          ${isCorrect ? 'border-green-400 bg-green-50' : 'border-transparent bg-slate-50'}`}>
                                          <button
                                            onClick={() => setEditQForm({...editQForm, correctOption: oi})}
                                            className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 transition-colors
                                              ${isCorrect ? 'bg-green-500 text-white' : 'bg-white border-2 border-slate-200 text-slate-500 hover:border-green-400'}`}
                                          >{lbl}</button>
                                          <input
                                            value={editQForm[key]}
                                            onChange={e => setEditQForm({...editQForm, [key]: e.target.value})}
                                            className="flex-1 bg-transparent outline-none text-sm text-slate-800 placeholder-slate-400"
                                            placeholder={`Option ${lbl}…`}
                                          />
                                          {isCorrect && <span className="text-[10px] font-bold text-green-600 shrink-0">✓ Correct</span>}
                                        </div>
                                      )
                                    })}
                                  </div>
                                </div>
                                <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1">Hint / Explanation</label>
                                  <input
                                    value={editQForm.explanation}
                                    onChange={e => setEditQForm({...editQForm, explanation: e.target.value})}
                                    className="input w-full" placeholder="Why is this the correct answer?"
                                  />
                                </div>
                                <div className="flex gap-3">
                                  <div className="flex-1">
                                    <label className="block text-xs font-bold text-slate-500 mb-1">Difficulty</label>
                                    <select
                                      value={editQForm.difficulty}
                                      onChange={e => setEditQForm({...editQForm, difficulty: e.target.value})}
                                      className="input w-full"
                                    >
                                      <option value="easy">Easy</option>
                                      <option value="medium">Medium</option>
                                      <option value="hard">Hard</option>
                                    </select>
                                  </div>
                                  <div className="flex-1">
                                    <label className="block text-xs font-bold text-slate-500 mb-1">Topic Tag</label>
                                    <input
                                      value={editQForm.topicTag}
                                      onChange={e => setEditQForm({...editQForm, topicTag: e.target.value})}
                                      className="input w-full" placeholder="e.g. Indian History"
                                    />
                                  </div>
                                </div>
                                <div className="flex gap-2 pt-1">
                                  <button
                                    onClick={async () => {
                                      if (!editQForm.question.trim()) { showToast('Question text required', 'error'); return }
                                      setSavingQ2(true)
                                      try {
                                        const letters = ['a','b','c','d']
                                        await api.quizzes.updateQuestion(q.id, {
                                          questionText:  editQForm.question.trim(),
                                          optionA:       editQForm.optionA.trim(),
                                          optionB:       editQForm.optionB.trim(),
                                          optionC:       (editQForm.optionCount || 4) >= 3 ? editQForm.optionC.trim() : '',
                                          optionD:       (editQForm.optionCount || 4) >= 4 ? editQForm.optionD.trim() : '',
                                          correctOption: letters[editQForm.correctOption] || 'a',
                                          explanation:   editQForm.explanation.trim() || null,
                                          difficulty:    editQForm.difficulty || 'medium',
                                          topicTag:      editQForm.topicTag.trim() || null,
                                        })
                                        // Update local state so list reflects change immediately
                                        setExistingQuestions(prev => prev.map((eq, idx) => idx !== i ? eq : {
                                          ...eq,
                                          question_text:  editQForm.question.trim(),
                                          option_a: editQForm.optionA, option_b: editQForm.optionB,
                                          option_c: editQForm.optionC, option_d: editQForm.optionD,
                                          correct_option: letters[editQForm.correctOption],
                                          explanation: editQForm.explanation,
                                          difficulty: editQForm.difficulty,
                                          topic_tag: editQForm.topicTag,
                                        }))
                                        setEditingQId(null)
                                        showToast('Question updated ✅')
                                      } catch (e: any) { showToast(e.message || 'Failed', 'error') }
                                      finally { setSavingQ2(false) }
                                    }}
                                    disabled={savingQ2}
                                    className="btn-primary text-sm"
                                  >
                                    {savingQ2 ? <><Loader2 size={13} className="animate-spin"/> Saving…</> : <><CheckCircle2 size={13}/> Save Changes</>}
                                  </button>
                                  <button onClick={() => setEditingQId(null)} className="btn-secondary text-sm">Cancel</button>
                                </div>
                              </div>
                            ) : (
                              /* ── Read mode ── */
                              <>
                                {q.question_image_url && <img src={q.question_image_url} alt="" className="max-h-20 rounded-xl mb-2 object-contain"/>}
                                <p className="text-sm font-semibold text-slate-800 mb-2">{q.question_text || q.question}</p>
                                {/* Match-the-following: show List-I/List-II so the question is
                                    readable — bare combination options were meaningless (QA 09-Jul issue 5) */}
                                {(() => {
                                  if ((q.question_subtype || 'standard') !== 'match') return null
                                  let md: any = q.match_data ?? q.matchData
                                  if (typeof md === 'string') { try { md = JSON.parse(md) } catch { md = null } }
                                  if (!md?.list1?.length || !md?.list2?.length) return null
                                  const rows = Math.max(md.list1.length, md.list2.length)
                                  return (
                                    <div className="mb-2 rounded-xl border border-blue-200 overflow-hidden">
                                      <div className="grid grid-cols-2 bg-blue-600 text-white text-[11px] font-black px-2.5 py-1.5">
                                        <span>List-I</span><span>List-II</span>
                                      </div>
                                      {Array.from({ length: rows }).map((_, ri) => (
                                        <div key={ri} className={`grid grid-cols-2 px-2.5 py-1.5 text-xs ${ri % 2 ? 'bg-blue-50/40' : 'bg-white'}`}>
                                          <span className="text-slate-700">{md.list1[ri] ? `${md.list1[ri].label}. ${md.list1[ri].text}` : ''}</span>
                                          <span className="text-slate-700">{md.list2[ri] ? `${md.list2[ri].label}. ${md.list2[ri].text}` : ''}</span>
                                        </div>
                                      ))}
                                    </div>
                                  )
                                })()}
                                <div className="grid grid-cols-2 gap-1.5">
                                  {opts.map((opt: string, oi: number) => (
                                    <div key={oi} className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs
                                      ${oi === correctIdx
                                        ? 'bg-green-100 text-green-800 font-semibold border border-green-200'
                                        : 'bg-white text-slate-600 border border-slate-200'}`}>
                                      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-black shrink-0
                                        ${oi === correctIdx ? 'bg-green-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
                                        {OPTION_LABELS[oi]}
                                      </span>
                                      {opt}
                                    </div>
                                  ))}
                                </div>
                                {(q.explanation || q.hint) && (
                                  <p className="text-xs text-blue-600 mt-2 bg-blue-50 px-2.5 py-1.5 rounded-lg">
                                    💡 {q.explanation || q.hint}
                                  </p>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              )}

              {/* Add questions tab — Issue 11: better UI */}
              {qTab === 'add' && (
                <div className="space-y-5">
                  {questions.map((q, i) => (
                    <div key={i} className="rounded-2xl border-2 border-slate-200 overflow-hidden">

                      {/* Q header */}
                      <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-200">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-brand-100 text-brand-700 text-xs font-black flex items-center justify-center">{i+1}</div>
                          <span className="text-sm font-bold text-slate-700">Question {i+1}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {/* Issue 13: option count picker */}
                          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-white rounded-lg border border-slate-200">
                            <span className="text-[10px] text-slate-500 font-medium">Options:</span>
                            {[2,3,4].map(n => (
                              <button key={n} onClick={() => setOptionCount(i, n)}
                                className={`w-6 h-6 rounded-md text-xs font-bold transition-colors
                                  ${q.optionCount===n?'bg-brand-500 text-white':'text-slate-500 hover:bg-slate-100'}`}>
                                {n}
                              </button>
                            ))}
                          </div>
                          {questions.length > 1 && (
                            <button onClick={() => setQuestions(prev => prev.filter((_,idx) => idx!==i))}
                              className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center">
                              <X size={13} className="text-red-500"/>
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="p-4 space-y-3">
                        {/* Question text */}
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1.5">Question Text *</label>
                          <textarea value={q.question} onChange={e => updateQ(i,'question',e.target.value)}
                            className="input resize-none h-16" placeholder="Type the question here…"/>
                        </div>

                        {/* Question subtype toggle */}
                        <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                          <span className="text-[10px] font-bold text-slate-500">Type:</span>
                          {(['standard','match'] as const).map(t => (
                            <button key={t} onClick={() => updateQ(i, 'questionSubtype', t)}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${q.questionSubtype === t ? 'bg-blue-600 text-white' : 'bg-white text-slate-500 hover:bg-slate-100 border border-slate-200'}`}>
                              {t === 'standard' ? '📝 Standard MCQ' : '🔗 Match the Following'}
                            </button>
                          ))}
                        </div>
                        {q.questionSubtype === 'match' && (
                          <MatchQuestionEditor q={q} qi={i} updateQ={updateQ} />
                        )}

                        {/* Options — Issue 13: dynamic count */}
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1.5">
                            {q.questionSubtype === 'match' ? 'Combination Options (A-D)' : 'Answer Options'}
                          </label>
                          <div className="space-y-2">
                            {q.options.map((opt: string, oi: number) => (
                              <div key={oi} className={`flex items-center gap-2 p-2 rounded-xl border-2 transition-colors
                                ${q.correctOption===oi?'border-green-400 bg-green-50':'border-transparent bg-slate-50'}`}>
                                <button onClick={() => updateQ(i,'correctOption',oi)}
                                  className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 transition-colors
                                    ${q.correctOption===oi?'bg-green-500 text-white':'bg-white border-2 border-slate-200 text-slate-500 hover:border-green-400'}`}>
                                  {OPTION_LABELS[oi]}
                                </button>
                                <input value={opt} onChange={e => updateOption(i, oi, e.target.value)}
                                  className="flex-1 bg-transparent outline-none text-sm text-slate-800 placeholder-slate-400"
                                  placeholder={`Option ${OPTION_LABELS[oi]}…`}/>
                                {q.correctOption === oi && (
                                  <span className="text-[10px] font-bold text-green-600 shrink-0">✓ Correct</span>
                                )}
                              </div>
                            ))}
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1.5">Click the letter button to mark the correct answer</p>
                        </div>

                        {/* Issue 14: Explanation = hint shown in app */}
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1.5">
                            Hint / Explanation
                            <span className="ml-1 text-blue-500 font-normal">(shown in app after answering)</span>
                          </label>
                          <input value={q.explanation} onChange={e => updateQ(i,'explanation',e.target.value)}
                            className="input" placeholder="Brief explanation of why the answer is correct…"/>
                        </div>
                      </div>
                    </div>
                  ))}

                  <button onClick={() => setQuestions(prev => [...prev, emptyQ()])}
                    className="w-full py-3 rounded-2xl border-2 border-dashed border-slate-300 text-sm text-slate-500 hover:border-brand-400 hover:text-brand-600 hover:bg-brand-50/30 transition-all font-semibold">
                    + Add Another Question
                  </button>
                </div>
              )}
            </div>

            {qTab === 'add' && (
              <div className="px-6 py-4 border-t border-slate-100 flex justify-between items-center bg-slate-50/50 shrink-0">
                <p className="text-xs text-slate-400">{questions.filter(q=>q.question.trim()).length} / {questions.length} questions filled</p>
                <div className="flex gap-3">
                  <button onClick={() => setShowQModal(false)} className="btn-secondary">Cancel</button>
                  <button onClick={handleSaveQuestions} disabled={savingQ}
                    className="btn-primary disabled:opacity-40">
                    {savingQ ? <><Loader2 size={14} className="animate-spin"/> Saving…</> : `Save ${questions.filter(q=>q.question.trim()).length} Questions`}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}